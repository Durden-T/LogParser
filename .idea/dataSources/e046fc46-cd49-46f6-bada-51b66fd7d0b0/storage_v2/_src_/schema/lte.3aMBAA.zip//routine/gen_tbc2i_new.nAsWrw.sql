create
    definer = root@localhost procedure gen_tbc2i_new(IN minimum int)
begin
    truncate tbc2inew;
	INSERT INTO lte.tbc2inew(serving_sector, interfering_sector, c2i_mean, c2i_std)
	select serving_sector,interfering_sector,avg(lte_sc_rsrp-lte_nc_rsrp),stddev(lte_sc_rsrp-lte_nc_rsrp)
	from lte.tbmrodata
	group by serving_sector,interfering_sector
	having count(lte_sc_rsrp)>=minimum;
end;

