create definer = root@localhost trigger cal_pss_and_totletilt
    before insert
    on tbcell
    for each row
begin
    set new.pss = new.pci % 3;
    set new.totletilt = new.electtilt + new.mechtilt;
end;

