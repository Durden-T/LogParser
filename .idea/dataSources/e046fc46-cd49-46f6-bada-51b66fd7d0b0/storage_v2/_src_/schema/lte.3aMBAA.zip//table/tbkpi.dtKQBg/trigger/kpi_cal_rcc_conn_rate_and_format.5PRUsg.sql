create definer = root@localhost trigger kpi_cal_rcc_conn_rate_and_format
    before insert
    on tbkpi
    for each row
begin
    if new.rcc_conn_att != 0 then
        set new.rcc_conn_rate = new.rcc_conn_succ / new.rcc_conn_att;
    end if;
    if instr(new.start_time, '/') = 3 then
        set @year = substr(new.start_time, 7, 4);
        set @month = left(new.start_time, 2);
        set @day = substr(new.start_time, 4, 2);
        set new.start_time = concat(@year, '-', @month, '-', @day, right(new.start_time, 9));
    end if;
end;

