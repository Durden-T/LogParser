create view authority_menu as
select `lte`.`sys_base_menus`.`id`                              AS `id`,
       `lte`.`sys_base_menus`.`created_at`                      AS `created_at`,
       `lte`.`sys_base_menus`.`updated_at`                      AS `updated_at`,
       `lte`.`sys_base_menus`.`deleted_at`                      AS `deleted_at`,
       `lte`.`sys_base_menus`.`menu_level`                      AS `menu_level`,
       `lte`.`sys_base_menus`.`parent_id`                       AS `parent_id`,
       `lte`.`sys_base_menus`.`path`                            AS `path`,
       `lte`.`sys_base_menus`.`name`                            AS `name`,
       `lte`.`sys_base_menus`.`hidden`                          AS `hidden`,
       `lte`.`sys_base_menus`.`component`                       AS `component`,
       `lte`.`sys_base_menus`.`title`                           AS `title`,
       `lte`.`sys_base_menus`.`icon`                            AS `icon`,
       `lte`.`sys_base_menus`.`sort`                            AS `sort`,
       `lte`.`sys_authority_menus`.`sys_authority_authority_id` AS `authority_id`,
       `lte`.`sys_authority_menus`.`sys_base_menu_id`           AS `menu_id`,
       `lte`.`sys_base_menus`.`keep_alive`                      AS `keep_alive`,
       `lte`.`sys_base_menus`.`default_menu`                    AS `default_menu`
from (`lte`.`sys_authority_menus`
         join `lte`.`sys_base_menus`
              on ((`lte`.`sys_authority_menus`.`sys_base_menu_id` = `lte`.`sys_base_menus`.`id`)));

