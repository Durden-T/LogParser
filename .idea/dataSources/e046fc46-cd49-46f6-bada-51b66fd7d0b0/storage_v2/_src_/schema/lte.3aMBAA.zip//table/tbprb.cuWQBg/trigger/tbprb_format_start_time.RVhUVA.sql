create definer = root@localhost trigger tbprb_format_start_time
    before insert
    on tbprb
    for each row
begin
    if instr(new.start_time, '/') = 3 then
        set @year = substr(new.start_time, 7, 4);
        set @month = left(new.start_time, 2);
        set @day = substr(new.start_time, 4, 2);
        set new.start_time = concat(@year, '-', @month, '-', @day, right(new.start_time, 9));
    end if;
end;

